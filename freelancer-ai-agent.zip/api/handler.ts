// DECOMMISSIONED: Logic moved to api/index.ts
export const config = { runtime: 'edge' };