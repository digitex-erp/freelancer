// DEPRECATED - This file is intentionally empty to prevent Vercel from deploying it as a function.
// All logic is now handled by api/index.ts
